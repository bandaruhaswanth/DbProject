-- Query to create a trigger that will run on new task creation to set task status to To-Do
CREATE TRIGGER TR_TASK_CREATION 
AFTER INSERT  
ON 
task
for each row
SET @Status_ID = 1;