-- Query to create index for Title column of project Table
CREATE INDEX idx_Project_Title
ON project (Title);


-- Query to create index for Title column of documents Table
CREATE INDEX idx_Doc_Title
ON documents (Title);



-- Query to create index for Title column of Tasks Table
CREATE INDEX idx_Task_Title
ON task (Title);