-- Query to create a view for Employee and Project Assignment
CREATE VIEW Project_Employee_Assignment AS
SELECT p.Title as "Project Name", e.Name AS "Employee Name"
FROM project p
INNER JOIN employee_project ep
ON p.id = ep.Project_ID
INNER JOIN employee e
ON e.id = ep.Employee_ID;


-- Query to create a view for Employee and Task Assignment
CREATE VIEW Employee_Task_Assignment AS
SELECT t.Title, t.Description, e.Name AS "Assigned To"
FROM task t, employee e
WHERE t.Assigned_User_ID = e.ID;