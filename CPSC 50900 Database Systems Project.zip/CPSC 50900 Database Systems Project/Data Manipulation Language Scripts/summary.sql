SELECT SUM(Budget) AS "Total Income" FROM project_history; 


SELECT COUNT(*) AS "In Progress Tasks" FROM task WHERE STATUS_ID = 2;