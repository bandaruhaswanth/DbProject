SELECT t.Title, t.Description, s.Title AS "Status"
FROM task t, status s
WHERE t.STATUS_ID = s.ID;


SELECT t.Title, t.Description, e.Name AS "Assigned To"
FROM task t, employee e
WHERE t.Assigned_User_ID = e.ID;


