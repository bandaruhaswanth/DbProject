-- Query to display the employees assigned to each project
SELECT p.Title as "Project Name", e.Name AS "Employee Name"
FROM project p
INNER JOIN employee_project ep
ON p.id = ep.Project_ID
INNER JOIN employee e
ON e.id = ep.Employee_ID;