SELECT Title FROM project
UNION
SELECT Budget FROM project_history;