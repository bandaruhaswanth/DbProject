UPDATE task SET Status_ID = 2 WHERE ID = 4;

UPDATE project_type SET Type_Name = "R&D" WHERE ID = 3;