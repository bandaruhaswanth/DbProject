INSERT INTO task 
(Title, Description, Status_ID, Assigned_User_ID, Project_ID) 
VALUES
("Login Functionality", "Enable login to the portal",1, 2, 1);


INSERT INTO status 
(Title) 
VALUES
("Testing");