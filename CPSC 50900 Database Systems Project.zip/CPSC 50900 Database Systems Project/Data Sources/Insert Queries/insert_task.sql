LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/task.csv' 
 INTO TABLE task FIELDS TERMINATED BY ';' (Title, Description, Status_ID, Assigned_User_ID, Project_ID);