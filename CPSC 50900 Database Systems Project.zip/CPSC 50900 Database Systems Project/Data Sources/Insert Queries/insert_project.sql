LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/project.csv' 
 INTO TABLE project FIELDS TERMINATED BY ';' (Title, Customer_ID, Project_Type);