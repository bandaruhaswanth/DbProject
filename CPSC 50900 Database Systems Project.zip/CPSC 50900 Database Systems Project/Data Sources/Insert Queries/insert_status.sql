LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/status.csv' 
 INTO TABLE status FIELDS TERMINATED BY ';' (Title);