LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/project_type.csv' 
 INTO TABLE project_type FIELDS TERMINATED BY ';' (Type_Name);