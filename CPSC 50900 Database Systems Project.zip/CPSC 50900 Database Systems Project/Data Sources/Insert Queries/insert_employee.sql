LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/employee.csv' 
 INTO TABLE employee FIELDS TERMINATED BY ';' (Name, Email, Role_ID);