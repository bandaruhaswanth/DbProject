LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/documents.csv' 
 INTO TABLE documents FIELDS TERMINATED BY ';' (Title, Project_ID);