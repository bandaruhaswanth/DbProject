LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/employee_project.csv' 
 INTO TABLE employee_project FIELDS TERMINATED BY ';' (Project_ID, Employee_ID);