LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/project_history.csv' 
 INTO TABLE project_history FIELDS TERMINATED BY ';' (Project_ID, Start_Date, End_Date, Budget);