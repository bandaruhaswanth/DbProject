LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/customer.csv' 
 INTO TABLE customer FIELDS TERMINATED BY ';' (Name, Email, Industry);