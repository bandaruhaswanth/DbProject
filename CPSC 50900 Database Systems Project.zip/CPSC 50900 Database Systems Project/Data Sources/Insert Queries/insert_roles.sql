LOAD DATA LOCAL INFILE 
 'C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Sources/roles.csv' 
 INTO TABLE roles FIELDS TERMINATED BY ';' (Role_Type);