--
-- Table structure for table customer
--

CREATE TABLE customer (
  ID int(11) NOT NULL,
  Name varchar(50) NOT NULL,
  Email varchar(50) NOT NULL,
  Industry varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table documents
--

CREATE TABLE documents (
  ID int(11) NOT NULL,
  Title varchar(255) NOT NULL,
  Project_ID int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table employee
--

CREATE TABLE employee (
  ID int(11) NOT NULL,
  Name varchar(255) NOT NULL,
  Email varchar(255) NOT NULL,
  Role_ID int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table employee_project
--

CREATE TABLE employee_project (
  ID int(11) NOT NULL,
  Project_ID int(11) NOT NULL,
  Employee_ID int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table project
--

CREATE TABLE project (
  ID int(11) NOT NULL,
  Title varchar(255) NOT NULL,
  Customer_ID int(11) NOT NULL,
  Project_Type int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table project_history
--

CREATE TABLE project_history (
  ID int(11) NOT NULL,
  Project_ID int(11) NOT NULL,
  Start_Date date NOT NULL,
  End_Date date NOT NULL,
  Budget decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table project_type
--

CREATE TABLE project_type (
  ID int(11) NOT NULL,
  Type_Name varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table roles
--

CREATE TABLE roles (
  ID int(11) NOT NULL,
  Role_Type varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table status
--

CREATE TABLE status (
  ID int(11) NOT NULL,
  Title varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table task
--

CREATE TABLE task (
  ID int(11) NOT NULL,
  Title varchar(255) NOT NULL,
  Description varchar(255) NOT NULL,
  Created_Date date NOT NULL DEFAULT current_timestamp(),
  Status_ID int(11) NOT NULL,
  Assigned_User_ID int(11) NOT NULL,
  Project_ID int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for table customer
--
ALTER TABLE customer
  ADD PRIMARY KEY (ID);

--
-- Indexes for table documents
--
ALTER TABLE documents
  ADD PRIMARY KEY (ID),
  ADD KEY FK_PROJECT_DOC (Project_ID);

--
-- Indexes for table employee
--
ALTER TABLE employee
  ADD PRIMARY KEY (ID),
  ADD KEY FK_ROLE_ID (Role_ID);

--
-- Indexes for table employee_project
--
ALTER TABLE employee_project
  ADD PRIMARY KEY (ID),
  ADD KEY FK_PROJECT_ID (Project_ID),
  ADD KEY FK_EMPLOYEE_ID (Employee_ID);

--
-- Indexes for table project
--
ALTER TABLE project
  ADD PRIMARY KEY (ID),
  ADD KEY FK_CUSTOMER (Customer_ID),
  ADD KEY FK_PROJET_TYPE (Project_Type);

--
-- Indexes for table project_history
--
ALTER TABLE project_history
  ADD PRIMARY KEY (ID),
  ADD KEY FK_PROJECT (Project_ID);

--
-- Indexes for table project_type
--
ALTER TABLE project_type
  ADD PRIMARY KEY (ID);

--
-- Indexes for table roles
--
ALTER TABLE roles
  ADD PRIMARY KEY (ID);

--
-- Indexes for table status
--
ALTER TABLE status
  ADD PRIMARY KEY (ID);

--
-- Indexes for table task
--
ALTER TABLE task
  ADD PRIMARY KEY (ID),
  ADD KEY FK_STATUS_ID (Status_ID),
  ADD KEY FK_TASK_PROJECT (Project_ID),
  ADD KEY FK_TASK_ASSIGNED_EMPLOYEE (Assigned_User_ID);

--
-- AUTO_INCREMENT for table customer
--
ALTER TABLE customer
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table documents
--
ALTER TABLE documents
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table employee
--
ALTER TABLE employee
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table employee_project
--
ALTER TABLE employee_project
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table project
--
ALTER TABLE project
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table project_history
--
ALTER TABLE project_history
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table project_type
--
ALTER TABLE project_type
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table roles
--
ALTER TABLE roles
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table status
--
ALTER TABLE status
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table task
--
ALTER TABLE task
  MODIFY ID int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for table documents
--
ALTER TABLE documents
  ADD CONSTRAINT FK_PROJECT_DOC FOREIGN KEY (Project_ID) REFERENCES project (ID) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table employee
--
ALTER TABLE employee
  ADD CONSTRAINT FK_ROLE_ID FOREIGN KEY (Role_ID) REFERENCES roles (ID) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table employee_project
--
ALTER TABLE employee_project
  ADD CONSTRAINT FK_EMPLOYEE_ID FOREIGN KEY (Employee_ID) REFERENCES employee (ID) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT FK_PROJECT_ID FOREIGN KEY (Project_ID) REFERENCES project (ID) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table project
--
ALTER TABLE project
  ADD CONSTRAINT FK_CUSTOMER FOREIGN KEY (Customer_ID) REFERENCES customer (ID) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT FK_PROJET_TYPE FOREIGN KEY (Project_Type) REFERENCES project_type (ID) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table project_history
--
ALTER TABLE project_history
  ADD CONSTRAINT FK_PROJECT FOREIGN KEY (Project_ID) REFERENCES project (ID) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table task
--
ALTER TABLE task
  ADD CONSTRAINT FK_STATUS_ID FOREIGN KEY (Status_ID) REFERENCES status (ID) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT FK_TASK_ASSIGNED_EMPLOYEE FOREIGN KEY (Assigned_User_ID) REFERENCES employee (ID) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT FK_TASK_PROJECT FOREIGN KEY (Project_ID) REFERENCES project (ID) ON DELETE NO ACTION ON UPDATE NO ACTION;