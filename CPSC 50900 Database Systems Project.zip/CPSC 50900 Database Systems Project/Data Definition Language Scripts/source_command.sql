CREATE DATABASE project_management;
USE project_management;
SOURCE C:/DATA/dev/work/CPSC 50900 Database Systems Project/Data Definition Language Scripts/script.sql;